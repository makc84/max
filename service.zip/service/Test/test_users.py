# encoding=utf8

import pytest
from hamcrest import *

from constant import Users, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

USER_ID = Users.USER_ID
USER = Users.USER
USER_CREATE = Users.USER_CREATE


# TODO Ищем пользователей по параметрам и сравниваем кол-во найденных
@pytest.mark.parametrize("dict, kol", [
    ({'id': 1}, 1),
    ({'id': 1, 'name': 'max'}, 0),
    ({'name': 'Kurtis Weissnat', 'username': 'Elwyn.Skiles'}, 1),
    ({'phone': '(775)976-6794 x41206'}, 1),
    ({'website': 'elvis.io'}, 0)
])
def test_get_user(confserv, dict, kol):
    with pytest.allure.step("Поиск пользателя "):
        url = 'https://jsonplaceholder.typicode.com/users/'
        list = confserv.jsonplaceholder.users.get_users(url, dict)
        print('list =' + str(len(list)))
        assert_that(len(list), equal_to(kol), u"Кол-во пользователей не совпало")

# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/users/'),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/users_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_code = confserv.jsonplaceholder.users.status_code(url)
        assert_that(status_code, equal_to(status), u"Url не доступен")


# TODO Получаем пользователя по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем пользователя по его id"):
        url_user = 'https://jsonplaceholder.typicode.com/users/?id='
        get_user = confserv.jsonplaceholder.users.get_by_id(url_user, USER_ID)
        assert_that(USER, equal_to(get_user[0]), u"Пользователь не найден")


# TODO Создаем пользователя
def test_users_create(confserv):
    with pytest.allure.step("Создаем пользователя"):
        create_user = 'https://jsonplaceholder.typicode.com/users/'
        status_user = confserv.jsonplaceholder.todos.create(create_user, USER_CREATE)
        assert_that(status_user, equal_to(STATUS_CREATED), u"Пользователь не создан")


# TODO Удаляем пользователя
def test_users_delete(confserv):
    with pytest.allure.step("Удаляем пользователя"):
        delete_user = 'https://jsonplaceholder.typicode.com/users/'
        status_user = confserv.jsonplaceholder.todos.delete(delete_user, USER_ID)
        assert_that(status_user, equal_to(STATUS_OK), u"Пользователь не удален")


