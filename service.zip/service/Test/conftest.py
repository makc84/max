# encoding=utf8

import pytest

import jsonplaceholder


class WORKPLACE:
    jsonplaceholder = jsonplaceholder.Jsonplaceholder()

@pytest.yield_fixture(scope='session')
def confserv():
    workplace = WORKPLACE()
    yield workplace