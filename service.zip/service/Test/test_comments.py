# encoding=utf8

import pytest
from hamcrest import *

from constant import Comments, Post, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

COMMENT = Comments.COMMENT
COMMENT_CREATED = Comments.COMMENT_CREATE
COMMENT_ID = Comments.COMMENT_ID
POST_ID = Post.POST_ID


# TODO Кол-во комментов по mail
@pytest.mark.parametrize("count, mail", [
    (1, 'Nikita@garfield.biz'),
    (1, 'Meghan_Littel@rene.us'),
    (0, 'test@test.ru')
])
def test_get_by_mail(confserv, count, mail):
    with pytest.allure.step("Проверяем колличеесто комментов по mail "):
        url = 'https://jsonplaceholder.typicode.com/comments?email='
        list_comment = confserv.jsonplaceholder.comments.get_by_mail(url, mail)
        assert_that(count, equal_to(len(list_comment)), u"Почтовый ящик не найден")


# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/comments'),
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/comments?postId=1' + str(POST_ID)),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/comments_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_code = confserv.jsonplaceholder.comments.status_code(url)
        assert_that(status_code, equal_to(status), u"Url не доступен")


# TODO Получаем коммент по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем коммент по его id"):
        url_comment = 'https://jsonplaceholder.typicode.com/comments/'
        get_comment = confserv.jsonplaceholder.comments.get_by_id(url_comment, COMMENT_ID)
        assert_that(COMMENT, equal_to(get_comment), u"Коммент не найде")


# TODO Создаем коммент
def test_comment_create(confserv):
    with pytest.allure.step("Создаем пост"):
        update_post = 'https://jsonplaceholder.typicode.com/comments/'
        status_code = confserv.jsonplaceholder.comments.create(update_post, COMMENT_CREATED)
        assert_that(status_code, equal_to(STATUS_CREATED), u"Коммент не создан")


# TODO Удаляем коммент
def test_comment_delete(confserv):
    with pytest.allure.step("Удаляем пост"):
        delete_comment = 'https://jsonplaceholder.typicode.com/comments/'
        status_code = confserv.jsonplaceholder.comments.delete(delete_comment, COMMENT_ID)
        assert_that(status_code, equal_to(STATUS_OK), u"Пост не удален")