# encoding=utf8

import pytest
from hamcrest import *

from constant import Post, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

POST = Post.POST
POST_CREATED = Post.POST_CREATE
POST_ID = Post.POST_ID
USER_ID = Post.USER_ID


# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/posts/'),
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/posts?userId=' + str(USER_ID)),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/posts_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_code = confserv.jsonplaceholder.post.status_code(url)
        assert_that(status_code, equal_to(status), u"Url не доступен")


# TODO Получаем пост по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем пост по его id"):
        url_post = 'https://jsonplaceholder.typicode.com/posts/?id='
        get_post = confserv.jsonplaceholder.post.get_by_id(url_post, POST_ID)
        assert_that(POST, equal_to(get_post[0]), u"Посты не найден")


# TODO Создаем пост
def test_post_create(confserv):
    with pytest.allure.step("Создаем пост"):
        create_post = 'https://jsonplaceholder.typicode.com/posts/'
        status_code = confserv.jsonplaceholder.post.create(create_post, POST_CREATED)
        assert_that(status_code, equal_to(STATUS_CREATED), u"Пост не создан")


# TODO Удаляем пост
def test_post_delete(confserv):
    with pytest.allure.step("Удаляем пост"):
        delete_post = 'https://jsonplaceholder.typicode.com/posts/'
        status_code = confserv.jsonplaceholder.post.delete(delete_post, POST_ID)
        assert_that(status_code, equal_to(STATUS_OK), u"Пост не удален")


