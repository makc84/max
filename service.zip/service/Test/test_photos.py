# encoding=utf8

import pytest
from hamcrest import *

from constant import Photos, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

PHOTO_ID = Photos.PHOTO_ID
PHOTO = Photos.PHOTO
PHOTO_CREATE = Photos.PHOTO_CREATE


# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/photos'),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/photos_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_photo = confserv.jsonplaceholder.photos.status_code(url)
        assert_that(status_photo, equal_to(status), u"Url не доступен")


# TODO Получаем фото по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем фото по его id"):
        url_photo = 'https://jsonplaceholder.typicode.com/photos/?id='
        get_photo = confserv.jsonplaceholder.photos.get_by_id(url_photo, PHOTO_ID)
        assert_that(PHOTO, equal_to(get_photo[0]), u"Фото не найдено")


# TODO Создаем фото
def test_photo_create(confserv):
    with pytest.allure.step("Добавляем фото"):
        create_photo = 'https://jsonplaceholder.typicode.com/photos/'
        status_photo = confserv.jsonplaceholder.photos.create(create_photo, PHOTO_CREATE)
        assert_that(status_photo, equal_to(STATUS_CREATED), u"Фото не создано")


# TODO Удаляем альбом
def test_photo_delete(confserv):
    with pytest.allure.step("Удаляем фото"):
        delete_photo = 'https://jsonplaceholder.typicode.com/photos/'
        status_photo = confserv.jsonplaceholder.photos.delete(delete_photo, PHOTO_ID)
        assert_that(status_photo, equal_to(STATUS_OK), u"Фото не удалено")


