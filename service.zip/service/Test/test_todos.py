# encoding=utf8

import pytest
from hamcrest import *

from constant import Todos, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

TODOS_ID = Todos.TODOS_ID
TODOS = Todos.TODOS
TODOS_CREATE = Todos.TODOS_CREATE


# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/todos/'),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/todos_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_code = confserv.jsonplaceholder.todos.status_code(url)
        assert_that(status_code, equal_to(status), u"Url не доступен")


# TODO Получаем todos по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем todos по его id"):
        url_todos = 'https://jsonplaceholder.typicode.com/todos/?id='
        get_todos = confserv.jsonplaceholder.todos.get_by_id(url_todos, TODOS_ID)
        assert_that(TODOS, equal_to(get_todos[0]), u"Todos не найден")


# TODO Создаем todos
def test_todos_create(confserv):
    with pytest.allure.step("Создаем todos"):
        create_todos = 'https://jsonplaceholder.typicode.com/todos/'
        status_todos = confserv.jsonplaceholder.todos.create(create_todos, TODOS_CREATE)
        assert_that(status_todos, equal_to(STATUS_CREATED), u"Todos не создан")


# TODO Удаляем todos
def test_todos_delete(confserv):
    with pytest.allure.step("Удаляем todos"):
        delete_todos = 'https://jsonplaceholder.typicode.com/todos/'
        status_todos = confserv.jsonplaceholder.todos.delete(delete_todos, TODOS_ID)
        assert_that(status_todos, equal_to(STATUS_OK), u"Todos не удален")


