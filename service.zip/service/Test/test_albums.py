# encoding=utf8

import pytest
from hamcrest import *

from constant import Alboms, STATUS_CREATED, STATUS_OK, STATUS_NOT_FOUND

ALBUM_ID = Alboms.ALBOM_ID
ALBUM = Alboms.ALBOM
ALBUM_CREATE = Alboms.ALBOM_CREATE


# TODO Проверяем доступность url
@pytest.mark.parametrize("status, url", [
    (STATUS_OK, 'https://jsonplaceholder.typicode.com/albums'),
    (STATUS_NOT_FOUND, 'https://jsonplaceholder.typicode.com/albums_no')
])
def test_status(confserv, status, url):
    with pytest.allure.step("Проверяем доступность url "):
        status_code = confserv.jsonplaceholder.albums.status_code(url)
        assert_that(status_code, equal_to(status), u"Url не доступен")


# TODO Получаем альбом по его id
def test_get_by_id(confserv):
    with pytest.allure.step("Получаем альбом по его id"):
        url_album = 'https://jsonplaceholder.typicode.com/albums/?id='
        get_album = confserv.jsonplaceholder.albums.get_by_id(url_album, ALBUM_ID)
        assert_that(ALBUM, equal_to(get_album[0]), u"Альбом не найден")


# TODO Создаем альбом
def test_album_create(confserv):
    with pytest.allure.step("Создаем альбом"):
        create_album = 'https://jsonplaceholder.typicode.com/albums/'
        status_album = confserv.jsonplaceholder.albums.create(create_album, ALBUM_CREATE)
        assert_that(status_album, equal_to(STATUS_CREATED), u"Альбом не создан")


# TODO Удаляем альбом
def test_album_delete(confserv):
    with pytest.allure.step("Удаляем альбом"):
        delete_album = 'https://jsonplaceholder.typicode.com/albums/'
        status_album = confserv.jsonplaceholder.albums.delete(delete_album, ALBUM_ID)
        assert_that(status_album, equal_to(STATUS_OK), u"Пост не удален")


