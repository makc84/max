from object import Object


class Photos(Object):pass