# encoding=utf8

from post import Post
from comments import Comments
from albums import Albums
from photos import Photos
from todos import Todos
from users import Users


class Jsonplaceholder:
    # Инициализируем классы
    def __init__(self):
        self.post = Post()
        self.comments = Comments()
        self.albums = Albums()
        self.photos = Photos()
        self.todos = Todos()
        self.users = Users()