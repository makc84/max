from req import *


class Object(object):
    # Проверяем ответ сервиса
    def status_code(self, url):
        response = request(url)
        return response.status_code

    # Получаем элемент по их id
    def get_by_id(self, url, id):
        response = request(url + str(id))
        return response.json()

    # Создаем запиь в БД
    def create(self, url, dict):
        response = create(url, dict)
        return response.status_code

    # Обновляем запиь в БД
    def update(self, url, dic):
        response = update(url, dic)
        return response.status_code

    # Удаляем запиь в БД
    def delete(self, url, id):
        response = delete(url + str(id))
        return response.status_code


