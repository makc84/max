# Ответ при создании
STATUS_CREATED = 201
# Ответ сервера, когда с сервисом ОК
STATUS_OK = 200
STATUS_NOT_FOUND = 404


class Post:
    # Ответ сервера, когда с сервисом ОК
    USER_ID = 1
    POST_ID = 3
    POST = {
        "userId": 1,
        "id": 3,
        "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
        "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
    }

    POST_CREATE = {
        "userId": 10,
        "id": 1010,
        "title": "TEST_TITLE",
        "body": "TEST_BODY"
    }

    POST_UPDATE = {
        "userId": 10,
        "id": 101,
        "title": "TEST_UPDATE",
        "body": "TEST_UPDATE"
    }


class Comments:
    COMMENT_ID = 1
    COMMENT = {
        "postId": 1,
        "id": 1,
        "name": "id labore ex et quam laborum",
        "email": "Eliseo@gardner.biz",
        "body": "laudantium enim quasi est quidem magnam voluptate ipsam eos\ntempora quo necessitatibus\ndolor quam autem quasi\nreiciendis et nam sapiente accusantium"
    }

    COMMENT_CREATE = {
        "postId": 1,
        "id": 1100,
        "name": "NAME_TEST",
        "email": "test@test.ru",
        "body": "Body_Test"
    }

class Alboms:
    ALBOM_ID = 1

    ALBOM = {
        "userId": 1,
        "id": 1,
        "title": "quidem molestiae enim"
    }

    ALBOM_CREATE = {
        "userId": 1,
        "id": 888,
        "title": "TITLE_CREATE"
    }

class Photos:
    PHOTO_ID = 1

    PHOTO = {
        "albumId": 1,
        "id": 1,
        "title": "accusamus beatae ad facilis cum similique qui sunt",
        "url": "https://via.placeholder.com/600/92c952",
        "thumbnailUrl": "https://via.placeholder.com/150/92c952"
    }

    PHOTO_CREATE = {
        "albumId": 1,
        "id": 180,
        "title": "TITLE_TEST",
        "url": "https://via.placeholder.com/test",
        "thumbnailUrl": "https://via.placeholder.com/testing/92c952"
    }

class Todos:
    TODOS_ID = 1

    TODOS = {
        "userId": 1,
        "id": 1,
        "title": "delectus aut autem",
        "completed": False
    }

    TODOS_CREATE = {
        "userId": 1,
        "id": 1020,
        "title": "TITLE_TEST",
        "completed": False
    }

class Users:
    USER_ID = 1
    USER = {
        "id": 1,
        "name": "Leanne Graham",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "address": {
            "street": "Kulas Light",
            "suite": "Apt. 556",
            "city": "Gwenborough",
            "zipcode": "92998-3874",
            "geo": {
                "lat": "-37.3159",
                "lng": "81.1496"
            }
        },
        "phone": "1-770-736-8031 x56442",
        "website": "hildegard.org",
        "company": {
            "name": "Romaguera-Crona",
            "catchPhrase": "Multi-layered client-server neural-net",
            "bs": "harness real-time e-markets"
        }
    }

    USER_CREATE = {
        "id": 1001,
        "name": "Ivan",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "address": {
            "street": "Kulas Light",
            "suite": "Apt. 556",
            "city": "Gwenborough",
            "zipcode": "92998-3874",
            "geo": {
                "lat": "-37.3159",
                "lng": "81.1496"
            }
        },
        "phone": "1-770-736-8031 x56442",
        "website": "hildegard.org",
        "company": {
            "name": "Romaguera-Crona",
            "catchPhrase": "Multi-layered client-server neural-net",
            "bs": "harness real-time e-markets"
        }
    }
