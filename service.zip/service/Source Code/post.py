from object import Object


class Post(Object): pass


