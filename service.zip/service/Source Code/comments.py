from object import Object
from req import *


class Comments(Object):
    def get_by_mail(self, url, mail):
        response = request(url + str(mail))
        return response.json()