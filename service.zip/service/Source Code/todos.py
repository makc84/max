from object import Object


class Todos(Object):pass