import requests


# Запросы
def request(url):
    return requests.get(url)


def create(url, dic):
    return requests.post(url, dic)


def update(url, dic):
    return requests.put(url, dic)


def delete(url):
    return requests.delete(url)
