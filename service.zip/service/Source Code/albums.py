from object import Object


class Albums(Object):pass