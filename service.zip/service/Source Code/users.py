from object import Object
from req import *


class Users(Object):
    def get_users(self, url, dict):
        # TODO Формирование поискового запроса
        sum_elem = len(dict.values())
        # Заходим в цикл, если dict имеет поисковые параметры
        if sum_elem > 0:
            find = '?'
            for key, value in dict.items():
                if value is not None:
                    find = find + key + '=' + str(value)
                    sum_elem -= 1
                    # Если кол-во параметров в dict > 1, в конце предыдущего ставим &
                    if sum_elem > 0:
                        find = find + '&'
        # TODO Отправка запроса
        response = request(url + find)
        return response.json()
